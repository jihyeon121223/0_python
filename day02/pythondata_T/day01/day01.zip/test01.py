# a = 0o177
# print(a)
# print(type(a))
# data = input('숫자를 입력하세요 : >>> ')
# data = int(data)
# print(data)
# print(type(data))


## 박스에 과일이 몇개 들어가고 몇개 남는지 출력
#입력- 박스당 과일의 수, 과일수
#출력 - oo박스 oo개

# inputdata1 = int(input('박스당 과일수 >>>'))
# inputdata2 = int(input('과일수 >>>'))
# print(inputdata2//inputdata1,'박스 ',inputdata2%inputdata1,'개')

# a = "hello world"
# b = 'hello world'
# c = """hello
# world"""
# d = "python's"
# e = '"python"'
# multiline = "Life is too short\nYou need python"
# print(a)
# print(b)
# print(c)
# print(d)
# print(e)
# print(multiline)

# print('python'+' is fun!')
# print('python '+2)
# print('python' * 2 )

print(len('life is too'))
word = 'life is too'
print(word[-3])
